import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean salir = false;

        while (!salir) {
            System.out.println("\n--- MENÚ PRINCIPAL ---");
            System.out.println("1. Buscar propietario por DNI");
            System.out.println("2. Buscar propietarios por apellidos");
            System.out.println("3. Agregar nuevo propietario manualmente");
            System.out.println("4. Salir");
            System.out.print("Elige una opción: ");

            int opcion = scanner.nextInt();
            scanner.nextLine(); // limpiar buffer

            switch (opcion) {
                case 1:
                    System.out.print("Introduce el DNI: ");
                    String dni = scanner.nextLine();
                    Propietario resultadoDni = Propietario.buscarPorDni(dni);
                    if (resultadoDni != null) {
                        System.out.println("Propietario encontrado: " + resultadoDni.getNombre() + " " + resultadoDni.getApellidos());
                        System.out.println("Puntos: " + resultadoDni.getNumeroPuntos());
                    } else {
                        System.out.println("No se encontró propietario con ese DNI.");
                    }
                    break;

                case 2:
                    System.out.print("Introduce el apellido: ");
                    String apellido = scanner.nextLine();
                    List<Propietario> resultadosApellido = Propietario.buscarPorApellidos(apellido);
                    if (resultadosApellido.isEmpty()) {
                        System.out.println("No se encontraron propietarios con ese apellido.");
                    } else {
                        System.out.println("\nPropietarios encontrados:");
                        for (Propietario p : resultadosApellido) {
                            System.out.println("- " + p.getNombre() + " " + p.getApellidos() + " (DNI: " + p.getDni() + ", Puntos: " + p.getNumeroPuntos() + ")");
                        }
                    }
                    break;

                case 3:
                    System.out.print("DNI: ");
                    String nuevoDni = scanner.nextLine();
                    System.out.print("Nombre: ");
                    String nuevoNombre = scanner.nextLine();
                    System.out.print("Apellidos: ");
                    String nuevosApellidos = scanner.nextLine();
                    System.out.print("Número de puntos: ");
                    int nuevosPuntos = scanner.nextInt();
                    scanner.nextLine(); // limpiar buffer

                    Propietario nuevoPropietario = new Propietario(nuevoDni, nuevoNombre, nuevosApellidos, nuevosPuntos);
                    nuevoPropietario.guardarEnBD();
                    break;

                case 4:
                    salir = true;
                    System.out.println("Saliendo del programa...");
                    break;

                default:
                    System.out.println("Opción no válida. Intenta nuevamente.");
            }
        }

        scanner.close();
    }
}
