import java.util.Date;

public class MotoAgua extends Moto {
    public MotoAgua(String matricula, String marca, int km, Date fechaFabricacion, Propietario propietario,
                    int potencia, String tipoMoto) {
        super(matricula, marca, km, fechaFabricacion, propietario, potencia, tipoMoto);
    }
}

