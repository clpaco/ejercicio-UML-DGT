import java.util.Date;

public class MotoCarretera extends Moto {
    public MotoCarretera(String matricula, String marca, int km, Date fechaFabricacion, Propietario propietario,
                         int potencia, String tipoMoto) {
        super(matricula, marca, km, fechaFabricacion, propietario, potencia, tipoMoto);
    }
}

