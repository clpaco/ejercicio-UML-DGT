import java.util.Date;

public class Moto extends Vehiculo {
    private int potencia;
    private String tipoMoto;

    public Moto(String matricula, String marca, int km, Date fechaFabricacion, Propietario propietario,
                int potencia, String tipoMoto) {
        super(matricula, marca, km, fechaFabricacion, propietario);
        this.potencia = potencia;
        this.tipoMoto = tipoMoto;
    }

    @Override
    public int obtenerEdad() {
        return super.obtenerEdad();
    }

    public int getPotencia() {
        return potencia;
    }

    public void setPotencia(int potencia) {
        this.potencia = potencia;
    }

    public String getTipoMoto() {
        return tipoMoto;
    }

    public void setTipoMoto(String tipoMoto) {
        this.tipoMoto = tipoMoto;
    }
}

