import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Propietario {
    private String dni;
    private String nombre;
    private String apellidos;
    private int numeroPuntos;

    public Propietario(String dni, String nombre, String apellidos, int numeroPuntos) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.numeroPuntos = numeroPuntos;
    }

    // Getters y setters...
    public String getDni() { return dni; }
    public String getNombre() { return nombre; }
    public String getApellidos() { return apellidos; }
    public int getNumeroPuntos() { return numeroPuntos; }

    public void guardarEnBD() {
        String sql = "INSERT INTO propietarios (dni, nombre, apellidos, numero_puntos) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, dni);
            stmt.setString(2, nombre);
            stmt.setString(3, apellidos);
            stmt.setInt(4, numeroPuntos);
            stmt.executeUpdate();
            System.out.println("Propietario guardado: " + nombre);
        } catch (SQLException e) {
            System.out.println("Error al guardar propietario: " + e.getMessage());
        }
    }

    public static Propietario buscarPorDni(String dniBuscado) {
        String sql = "SELECT * FROM propietarios WHERE dni = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, dniBuscado);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Propietario(
                        rs.getString("dni"),
                        rs.getString("nombre"),
                        rs.getString("apellidos"),
                        rs.getInt("numero_puntos")
                );
            }
        } catch (SQLException e) {
            System.out.println("Error al buscar por DNI: " + e.getMessage());
        }
        return null;
    }

    public static List<Propietario> buscarPorApellidos(String apellidosBuscado) {
        List<Propietario> lista = new ArrayList<>();
        String sql = "SELECT * FROM propietarios WHERE apellidos = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, apellidosBuscado);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                lista.add(new Propietario(
                        rs.getString("dni"),
                        rs.getString("nombre"),
                        rs.getString("apellidos"),
                        rs.getInt("numero_puntos")
                ));
            }
        } catch (SQLException e) {
            System.out.println("Error al buscar por apellidos: " + e.getMessage());
        }
        return lista;
    }
}
