import java.util.Date;

public abstract class Vehiculo {
    protected String matricula;
    protected String marca;
    protected int km;
    protected Date fechaFabricacion;
    protected Propietario propietario;

    public Vehiculo(String matricula, String marca, int km, Date fechaFabricacion, Propietario propietario) {
        this.matricula = matricula;
        this.marca = marca;
        this.km = km;
        this.fechaFabricacion = fechaFabricacion;
        this.propietario = propietario;
    }

    public int obtenerEdad() {
        Date actual = new Date();
        long diferencia = actual.getTime() - fechaFabricacion.getTime();
        return (int) (diferencia / (1000L * 60 * 60 * 24 * 365));
    }

    // Getters y setters


    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getKm() {
        return km;
    }

    public void setKm(int km) {
        this.km = km;
    }

    public Date getFechaFabricacion() {
        return fechaFabricacion;
    }

    public void setFechaFabricacion(Date fechaFabricacion) {
        this.fechaFabricacion = fechaFabricacion;
    }

    public Propietario getPropietario() {
        return propietario;
    }

    public void setPropietario(Propietario propietario) {
        this.propietario = propietario;
    }
}

