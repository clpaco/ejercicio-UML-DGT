import java.util.Date;

public class Coche extends Vehiculo {
    private int numeroAsientos;
    private int asientos;
    private boolean tieneSillaBebe;

    public Coche(String matricula, String marca, int km, Date fechaFabricacion, Propietario propietario,
                 int numeroAsientos, int asientos, boolean tieneSillaBebe) {
        super(matricula, marca, km, fechaFabricacion, propietario);
        this.numeroAsientos = numeroAsientos;
        this.asientos = asientos;
        this.tieneSillaBebe = tieneSillaBebe;
    }

    @Override
    public int obtenerEdad() {
        return super.obtenerEdad();
    }

    public int getNumeroAsientos() {
        return numeroAsientos;
    }

    public void setNumeroAsientos(int numeroAsientos) {
        this.numeroAsientos = numeroAsientos;
    }

    public int getAsientos() {
        return asientos;
    }

    public void setAsientos(int asientos) {
        this.asientos = asientos;
    }

    public boolean isTieneSillaBebe() {
        return tieneSillaBebe;
    }

    public void setTieneSillaBebe(boolean tieneSillaBebe) {
        this.tieneSillaBebe = tieneSillaBebe;
    }
}

