import java.util.Date;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Crear propietarios (se agregan automáticamente al registro)
        Propietario propietario1 = new Propietario("11111111A", "Carlos", "López", 10);
        Propietario propietario2 = new Propietario("22222222B", "Ana", "García", 15);
        Propietario propietario3 = new Propietario("33333333C", "María", "López", 8);

        // Buscar por DNI
        Propietario resultadoDni = Propietario.buscarPorDni("22222222B");
        if (resultadoDni != null) {
            System.out.println("Propietario encontrado por DNI:");
            System.out.println(resultadoDni.getNombre() + " " + resultadoDni.getApellidos());
        } else {
            System.out.println("No se encontró propietario con ese DNI.");
        }

        // Buscar por apellidos
        List<Propietario> resultadosApellido = Propietario.buscarPorApellidos("López");
        System.out.println("\nPropietarios con apellido 'López':");
        for (Propietario p : resultadosApellido) {
            System.out.println(p.getNombre() + " " + p.getApellidos() + " (Puntos: " + p.getNumeroPuntos() + ")");
        }

        // Crear vehículos
        Coche coche = new Coche(
                "XYZ123",
                "Peugeot",
                120000,
                new Date(112, 0, 1), // Año 2012
                propietario1,
                5,
                5,
                true
        );

        MotoCarretera moto = new MotoCarretera(
                "MOT999",
                "Kawasaki",
                35000,
                new Date(118, 3, 15), // Año 2018
                propietario2,
                200,
                "Deportiva"
        );

        // Mostrar edad de los vehículos
        System.out.println("\nEdad del coche: " + coche.obtenerEdad() + " años");
        System.out.println("Edad de la moto: " + moto.obtenerEdad() + " años");

        // Mostrar propietario de la moto
        System.out.println("\nPropietario de la moto: " + moto.propietario.getNombre() + " " + moto.propietario.getApellidos());
    }
}
