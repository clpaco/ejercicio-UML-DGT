public class Oficina {
    private int id;
    private String ciudad;
    private String codigoPostal;
    private String direccionOficinas;
    private boolean puedeGestCobros;
    private String empresaLimpieza;

    public Oficina(int id, String ciudad, String direccionOficinas, String codigoPostal, boolean puedeGestCobros, String empresaLimpieza) {
        this.id = id;
        this.ciudad = ciudad;
        this.direccionOficinas = direccionOficinas;
        this.codigoPostal = codigoPostal;
        this.puedeGestCobros = puedeGestCobros;
        this.empresaLimpieza = empresaLimpieza;
    }

    public Oficina() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getCodigoPostal() {
        return codigoPostal;
    }

    public void setCodigoPostal(String codigoPostal) {
        this.codigoPostal = codigoPostal;
    }

    public String getDireccionOficinas() {
        return direccionOficinas;
    }

    public void setDireccionOficinas(String direccionOficinas) {
        this.direccionOficinas = direccionOficinas;
    }

    public boolean isPuedeGestCobros() {
        return puedeGestCobros;
    }

    public void setPuedeGestCobros(boolean puedeGestCobros) {
        this.puedeGestCobros = puedeGestCobros;
    }

    public String getEmpresaLimpieza() {
        return empresaLimpieza;
    }

    public void setEmpresaLimpieza(String empresaLimpieza) {
        this.empresaLimpieza = empresaLimpieza;
    }

}

