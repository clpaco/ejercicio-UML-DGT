import java.util.ArrayList;
import java.util.List;

public class Propietario {
    private String dni;
    private String nombre;
    private String apellidos;
    private int numeroPuntos;

    // Lista estática simulando una base de datos de propietarios
    private static List<Propietario> propietariosRegistrados = new ArrayList<>();

    // Constructor
    public Propietario(String dni, String nombre, String apellidos, int numeroPuntos) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.numeroPuntos = numeroPuntos;

        // Agregamos al registro (simulación)
        propietariosRegistrados.add(this);
    }

    // Getters y setters
    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public int getNumeroPuntos() {
        return numeroPuntos;
    }

    public void setNumeroPuntos(int numeroPuntos) {
        this.numeroPuntos = numeroPuntos;
    }

    // Buscar propietario por DNI
    public static Propietario buscarPorDni(String dni) {
        for (Propietario p : propietariosRegistrados) {
            if (p.getDni().equals(dni)) {
                return p;
            }
        }
        return null; // No encontrado
    }

    // Buscar propietarios por apellido
    public static List<Propietario> buscarPorApellidos(String apellidos) {
        List<Propietario> resultado = new ArrayList<>();
        for (Propietario p : propietariosRegistrados) {
            if (p.getApellidos().equalsIgnoreCase(apellidos)) {
                resultado.add(p);
            }
        }
        return resultado;
    }
}
